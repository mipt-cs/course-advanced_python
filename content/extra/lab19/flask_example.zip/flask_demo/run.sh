export FLASK_APP=flask_app
export FLASK_ENV="development"

flask run --host=localhost --port=5000
